﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Карточка_товара
{
    /// <summary>
    /// Логика взаимодействия для UserControl_product_page.xaml
    /// </summary>
    public partial class UserControl_product_page : UserControl
    {
        //переменная отслеживающая передвижение "карусели" влево и вправо 
        private int Shift_Index = 0;
        private const double Step = 300;

        public UserControl_product_page()
        {
            InitializeComponent();

        }

        private void Right_Click(object sender, RoutedEventArgs e)
        {
            Move(1);
        }
        private void Left_Click(object sender, RoutedEventArgs e)
        {
            Move(-1);
        }

        //метод для передвижения "карусели" влево и вправо с анимацией
        private void Move(int direction)
        {
            int count = Carusel.Children.Count;
            if (count == 0)
            {
                return;
            }

            int newIndex = Shift_Index + direction;

            if (newIndex < 0)
            {
                newIndex = count-1;
            }

            if (newIndex > count-1)
            {
                newIndex = 0;
            }


            if (newIndex == Shift_Index)
            {
                return;
            }

            Shift_Index = newIndex;

            double targetX = -Shift_Index * Step;

            double currentX = (double)Shift.GetValue(TranslateTransform.XProperty);

            var animation = new DoubleAnimation
            {
                From = currentX,
                To = targetX,
                Duration = TimeSpan.FromMilliseconds(300),
                EasingFunction = new QuadraticEase
                {
                    EasingMode = EasingMode.EaseInOut
                }
            };

            Shift.BeginAnimation(TranslateTransform.XProperty, animation);
        }

        //метод для добавления изображения в "карусель"
        private void Add_Picture_Click(object sender, RoutedEventArgs e)
        {
            Rectangle rect = new Rectangle(); 
            rect.Width = 250; rect.Height = 250;
            rect.Fill = new SolidColorBrush(Colors.Red);
            rect.Margin = new Thickness(0,0,50,0);
            Carusel.Children.Add(rect);

        }
        //метод для удаления изображения из "карусели"
        private void Cut_Picture_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult MBResult;
            MBResult = MessageBox.Show("Вы уверены что хотите удалить изображение?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (MBResult == MessageBoxResult.Yes)
            {
                Carusel.Children.RemoveAt(Shift_Index);
            }
        }
    }
}

